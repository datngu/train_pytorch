from train_pytorch.trainer import (
    Trainer,
    binary_accuracy,
    multiple_class_accuracy,
    regression_r2,

)